let myShip;
let speed = 0;
let n = 10;
let drops = [];
let flowers = [];
let shot = document
function setup() {
  createCanvas(500, 1000);
  myShip = new Ship(100);
  let r = width / n / 2;
  console.log(r);
  for (let i = 0; i < n; i++) {
    flowers[i] = new Flower(i * 2 * r + r, r, r);
    flowers[i].mergine = 10;
  }
}
console.log("hi")

function inputs() {
  if (keyIsDown(LEFT_ARROW)) {
    myShip.move(-1);
  } else if (keyIsDown(RIGHT_ARROW)) {
    myShip.move(1);
  }
}
function draw() {
  background(255);
  drops.forEach(dropTask);
  drops.forEach((x) => x.show());
  if (flowers.length == 0) {
    prompt("YOU WIN");
  }
  flowerSide();
  myShip.show();
  flowers.forEach((x) => x.show());
  inputs();
}
function flowerSide() {
  let first = flowers[0];
  let last = flowers[flowers.length - 1];
  if (first.x < 0 || last.x > width) {
    speed *= -1;
  }
  flowers.forEach((f) => (f.x += speed));
}
function keyPressed() {
  if (keyCode === UP_ARROW) {
    drops.push(new Drop(myShip.x, myShip.y, myShip.size / 5));
  }
}
function tocuhStarted() {
  if (dist(mouseX, mouseY, myShip.x, myShip.y) < myShip.size) {
    drops.push(new Drop(myShip.x, myShip.y, myShip.size / 5));
  }
  if (mouseX > myShip.x) {
    myShip.move(-1);
  } else {
    myShip.move(-1);
  }
}

function dropTask(drop, i) {
  drops[i].show();
  let remove = false;
  flowers.forEach((f, j) => {
    if (dist(f.x, f.y, drop.x, drop.y) < 2 * f.r - 2 * f.mergine) {
      f.r += 2;
      f.alp -= 10;
      if (f.r > width / n - f.mergine) {
        flowers.splice(j, 1);
        flowers.forEach((x) => (x.y += x.r / 2));
        speed = f.y / 20;
      }
      remove = true;
    }
  });
  drops[i].move(10);
  if (drop.y < 0 || remove) {
    drops.splice(i, 1);
  }
}
