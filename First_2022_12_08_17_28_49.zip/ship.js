function Ship(size) {
  this.x = width / 2;
  this.y = height - size / 2
  this.size = size
  this.show = function() {
    fill(200, 0, 100);
    rectMode(CENTER)
    rect(this.x, this.y, size)
  }
  this.move = function(dir) {
    this.x += dir * 5
  }
}