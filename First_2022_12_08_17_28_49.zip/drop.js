function Drop(x, y, size) {
  this.x = x;
  this.y = y;
  this.r = size;
  this.move = (m) => this.y -= m;
  this.show = function() {
    fill(0, 255, 255);
    ellipseMode(CENTER);
    ellipse(this.x, this.y, this.r * 2);
  }
}