function Flower(x, y, r) {
  this.rgb = color(random(100, 255), random(100, 255), random(100, 255));
  this.alp = 255;
  this.mergine = 0;
  this.r = r;
  this.x = x;
  this.y = y;
  this.show = function() {
    noStroke();
    this.rgb.setAlpha(this.alp);
    fill(this.rgb);
    ellipseMode(CENTER);
    ellipse(this.x, this.y, 2 * this.r - this.mergine);
  }
}